package com.phamleminh.quanlysinhvien;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KetNoiSQL {

    public static Connection getConnection() {

        String url = "jdbc:sqlserver://localhost\\SQLEXPRESS;"
                + "databaseName=QuanLySinhVien;"
                + "integratedSecurity=true;"
                + "encrypt=true;"
                + "trustServerCertificate=true;";

        try {
            Connection conn = DriverManager.getConnection(url);
            System.out.println("Kết nối SQL Server thành công!");
            return conn;

        } catch (SQLException e) {
            System.out.println("Kết nối thất bại!");
            e.printStackTrace();
            return null;
        }
    }
}