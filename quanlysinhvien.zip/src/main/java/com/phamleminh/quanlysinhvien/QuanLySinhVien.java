/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.phamleminh.quanlysinhvien;

/**
 *
 * @author kingo
 */
public class QuanLySinhVien {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
